import streamlit as st
import pandas as pd
import plotly.express as px
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT/"outputs"
st.set_page_config(page_title="PharmEasy Regional Pulse",layout="wide")
st.title("PharmEasy Regional Pulse — Q2 2026")
st.caption("Streamlit + Plotly dashboard")
df=pd.read_csv(OUT/"orders_clean.csv",parse_dates=["order_date"]); df["month"]=df.order_date.dt.strftime("%Y-%m")
regions=["All"]+sorted(df.region.unique())
selected=st.sidebar.selectbox("Region",regions); view=df if selected=="All" else df[df.region==selected]
sales=view.sales_inr.sum(); profit=view.profit_inr.sum(); orders=view.order_id.nunique()
margin=profit/sales*100 if sales else 0
c1,c2,c3,c4=st.columns(4); c1.metric("Sales (INR)",f"₹{sales:,.0f}"); c2.metric("Profit (INR)",f"₹{profit:,.0f}"); c3.metric("Distinct Orders",f"{orders:,}"); c4.metric("Profit Margin",f"{margin:.1f}%")
st.markdown("**Executive summary:** This dashboard presents validated sales, profit and distinct-order KPIs, regional trend, category contribution and region-month detail. The 8% MoM rule is a monitoring heuristic, not a statistical test.")
trend=view.groupby(["month","region"],as_index=False).sales_inr.sum()
fig=px.line(trend,x="month",y="sales_inr",color="region",markers=True,title="How did sales change from April to June 2026?",labels={"sales_inr":"Sales (INR)","month":"Month","region":"Region"}); fig.update_yaxes(rangemode="tozero"); st.plotly_chart(fig,use_container_width=True)
regional=view.groupby("region",as_index=False).sales_inr.sum().sort_values("sales_inr",ascending=False)
fig2=px.bar(regional,x="region",y="sales_inr",title="Which regions contributed the most Q2 sales?",labels={"sales_inr":"Sales (INR)","region":"Region"}); fig2.update_yaxes(rangemode="tozero"); st.plotly_chart(fig2,use_container_width=True)
cat=view.groupby("category",as_index=False).sales_inr.sum()
fig3=px.pie(cat,names="category",values="sales_inr",hole=.45,title="What drove Q2 sales by category?"); st.plotly_chart(fig3,use_container_width=True)
st.subheader("Region-Month Detail")
detail=view.groupby(["region","month"],as_index=False).agg(sales_inr=("sales_inr","sum"),profit_inr=("profit_inr","sum"),orders=("order_id","nunique"))
detail["profit_margin_pct"]=(detail.profit_inr/detail.sales_inr*100).round(2); st.dataframe(detail,use_container_width=True)
st.subheader("Monitoring Flags")
growth=pd.read_csv(OUT/"regional_growth.csv"); st.dataframe(growth if selected=="All" else growth[growth.region==selected],use_container_width=True)
