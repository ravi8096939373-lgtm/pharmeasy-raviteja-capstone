from pathlib import Path
import pandas as pd, json
ROOT=Path(__file__).resolve().parents[1]; DATA=ROOT/"data"; OUT=ROOT/"outputs"; OUT.mkdir(exist_ok=True)
REQUIRED=["order_id","order_date","region","category","product","quantity","sales_inr","profit_inr"]
CANONICAL=["Hyderabad","Warangal","Visakhapatnam","Guntur","Tirupati","Karimnagar","Bengaluru","Vijayawada","Nellore"]
ALIASES={"blr":"Bengaluru"}
def validate_schema(df,required=REQUIRED):
    missing=[c for c in required if c not in df.columns]
    return {"status":"blocked_schema" if missing else "validated","missing_columns":missing,"row_count":int(len(df))}
def normalize_region(v):
    if pd.isna(v): return None
    x=str(v).strip(); k=x.lower()
    if k in ALIASES:return ALIASES[k]
    lookup={r.lower():r for r in CANONICAL}
    return lookup.get(k,x.title())
def clean_orders():
    raw=pd.read_csv(DATA/"pharmeasy_orders_raw.csv"); schema=validate_schema(raw)
    if schema["status"]!="validated": raise ValueError(schema)
    dedup=raw.drop_duplicates().copy(); dup_removed=len(raw)-len(dedup)
    dedup["region"]=dedup["region"].apply(normalize_region)
    product_category=(dedup.dropna(subset=["category"]).drop_duplicates("product").set_index("product")["category"].to_dict())
    cat_missing=int(dedup["category"].isna().sum()); dedup["category"]=dedup["category"].fillna(dedup["product"].map(product_category))
    dedup["sales_inr"]=pd.to_numeric(dedup["sales_inr"],errors="coerce"); dedup["profit_inr"]=pd.to_numeric(dedup["profit_inr"],errors="coerce")
    margins=(dedup.dropna(subset=["profit_inr"]).assign(margin=lambda x:x.profit_inr/x.sales_inr).groupby("category")["margin"].mean().to_dict())
    profit_missing=int(dedup["profit_inr"].isna().sum())
    dedup["profit_inr"]=dedup.apply(lambda r: round(r.sales_inr*margins[r.category],2) if pd.isna(r.profit_inr) else r.profit_inr,axis=1)
    master=pd.read_csv(DATA/"regions_master.csv"); allowed=set(master.loc[master.active_flag.eq(1),"region"])
    if set(dedup.region)-allowed: raise ValueError("Invalid region remains")
    if dedup.order_id.duplicated().any(): raise ValueError("Duplicate order_id remains")
    if dedup[REQUIRED].isna().any().any(): raise ValueError("Missing required values remain")
    dedup["order_date"]=pd.to_datetime(dedup.order_date).dt.strftime("%Y-%m-%d"); dedup=dedup.sort_values("order_id").reset_index(drop=True)
    dedup.to_csv(OUT/"orders_clean.csv",index=False)
    report={"raw_rows":len(raw),"unique_rows_after_dedup":len(dedup),"duplicates_removed":dup_removed,
            "category_missing_filled":cat_missing,"profit_missing_filled":profit_missing,
            "raw_region_variants":int(raw.region.nunique()),"clean_regions":int(dedup.region.nunique()),
            "final_missing_cells":int(dedup[REQUIRED].isna().sum().sum()),
            "final_duplicate_order_ids":int(dedup.order_id.duplicated().sum()),"schema_status":schema["status"]}
    (OUT/"data_quality_report.json").write_text(json.dumps(report,indent=2))
    return dedup,report
if __name__=="__main__": print(json.dumps(clean_orders()[1],indent=2))
