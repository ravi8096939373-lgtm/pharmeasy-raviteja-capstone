from pathlib import Path
import numpy as np, pandas as pd

ROOT=Path(__file__).resolve().parents[1]; DATA=ROOT/"data"; DATA.mkdir(exist_ok=True)
SEED=2026
np.random.seed(SEED); rng=np.random.default_rng(SEED)
regions=["Hyderabad","Warangal","Visakhapatnam","Guntur","Tirupati","Karimnagar","Bengaluru","Vijayawada","Nellore"]
categories=["OTC Medicines","Prescription Medicines","Wellness","Personal Care","Baby Care","Devices"]
products={"OTC Medicines":["Paracetamol","Vitamin C","Cough Syrup","Antacid"],
"Prescription Medicines":["Antibiotic A","Diabetes Tablet","BP Tablet","Thyroid Tablet"],
"Wellness":["Protein Powder","Multivitamin","Omega 3","Herbal Supplement"],
"Personal Care":["Face Wash","Moisturizer","Shampoo","Sunscreen"],
"Baby Care":["Baby Lotion","Diaper Pack","Baby Wipes","Feeding Bottle"],
"Devices":["Thermometer","BP Monitor","Glucometer","Oximeter"]}
targets={"Hyderabad":[180000,190000,200000],"Warangal":[120000,135000,125000],
"Visakhapatnam":[210000,235000,220000],"Guntur":[100000,222190,210000],
"Tirupati":[150000,170000,155000],"Karimnagar":[110000,125000,140000],
"Bengaluru":[240000,250000,245000],"Vijayawada":[200000,220000,250000],"Nellore":[130000,135000,138000]}
counts={r:[78,78,77] for r in regions}
for r in regions[-3:]: counts[r]=[78,78,78]
rows=[]; oid=1000001
for r in regions:
    for mi,month in enumerate([4,5,6]):
        n=counts[r][mi]; weights=np.random.dirichlet(np.ones(6))
        cat_counts=np.random.multinomial(n,weights); cat_sales=targets[r][mi]*weights
        for cat,cnt,total in zip(categories,cat_counts,cat_sales):
            if cnt==0: continue
            vals=np.random.uniform(700,5000,size=cnt); vals=vals/vals.sum()*total
            for j,s in enumerate(vals):
                day=np.random.randint(1,[30,31,30][mi]+1); margin=np.random.uniform(.08,.28)
                rows.append([f"ORD{oid}",f"2026-{month:02d}-{day:02d}",r,cat,products[cat][j%4],
                             max(1,int(round(s/1200))),round(float(s),2),round(float(s*margin),2)])
                oid+=1
df=pd.DataFrame(rows,columns=["order_id","order_date","region","category","product","quantity","sales_inr","profit_inr"])
for month,targetv in [("2026-04",100000.0),("2026-05",222190.0),("2026-06",210000.0)]:
    mask=(df.region=="Guntur")&(df.order_date.str[:7]==month)
    idx=df.index[mask][0]; df.loc[idx,"sales_inr"]=round(df.loc[idx,"sales_inr"]+(targetv-df.loc[mask,"sales_inr"].sum()),2)
cat_missing=rng.choice(df.index,48,replace=False)
remaining=np.array([i for i in df.index if i not in set(cat_missing)])
profit_missing=rng.choice(remaining,94,replace=False)
df.loc[cat_missing,"category"]=None; df.loc[profit_missing,"profit_inr"]=None
variants=[("Hyderabad","Hyderabad"),("hyderabad","Hyderabad"),("Warangal","Warangal"),("WARANGAL ","Warangal"),
("Visakhapatnam","Visakhapatnam"),("visakhapatnam ","Visakhapatnam"),("Guntur","Guntur"),(" GUNTUR","Guntur"),
("Tirupati","Tirupati"),("TIRUPATI","Tirupati"),("Karimnagar","Karimnagar"),("karimnagar ","Karimnagar"),
("Bengaluru","Bengaluru"),("BLR","Bengaluru"),("Vijayawada","Vijayawada"),("Nellore","Nellore")]
m={}
for a,c in variants:m.setdefault(c,[]).append(a)
for c in regions:
    idx=df.index[df.region==c].tolist(); vals=m[c]
    for j,i in enumerate(idx): df.loc[i,"region"]=vals[j%len(vals)]
raw=pd.concat([df,df.loc[rng.choice(df.index,59,replace=False)]],ignore_index=True)
raw.to_csv(DATA/"pharmeasy_orders_raw.csv",index=False)
pd.DataFrame({"region_id":range(1,11),"region":regions+["Kurnool"],"active_flag":[1]*9+[0]}).to_csv(DATA/"regions_master.csv",index=False)
assert len(raw)==2159 and raw.drop_duplicates().shape[0]==2100 and raw.region.nunique()==16
print("Generated 2,159 raw rows; 2,100 unique rows; 59 exact duplicates; 16 raw region variants.")
