from pathlib import Path
import sqlite3,json
from datetime import datetime,timezone
import pandas as pd
from clean_data import clean_orders
ROOT=Path(__file__).resolve().parents[1]; DATA=ROOT/"data"; OUT=ROOT/"outputs"; OUT.mkdir(exist_ok=True)
def pct_change(c,p): return 0.0 if p==0 else round((c/p-1)*100,2)
def save_state(n,p): (OUT/n).write_text(json.dumps(p,indent=2,sort_keys=True))
def main():
    df,dq=clean_orders(); db=OUT/"pharmeasy.db"
    if db.exists():db.unlink()
    con=sqlite3.connect(db); pd.read_csv(DATA/"regions_master.csv").to_sql("regions_master",con,index=False,if_exists="replace"); df.to_sql("orders_clean",con,index=False,if_exists="replace")
    checks={}
    checks["left_join_count"]=con.execute("SELECT COUNT(*) FROM regions_master r LEFT JOIN orders_clean o ON r.region=o.region").fetchone()[0]
    checks["inner_join_count"]=con.execute("SELECT COUNT(*) FROM regions_master r INNER JOIN orders_clean o ON r.region=o.region").fetchone()[0]
    checks["orders_count"]=con.execute("SELECT COUNT(*) FROM orders_clean").fetchone()[0]
    checks["duplicate_key_count"]=con.execute("SELECT COUNT(*) FROM (SELECT order_id FROM orders_clean GROUP BY order_id HAVING COUNT(*)>1)").fetchone()[0]
    checks["kurnool_order_count"]=con.execute("SELECT COUNT(o.order_id) FROM regions_master r LEFT JOIN orders_clean o ON r.region=o.region WHERE r.region='Kurnool'").fetchone()[0]
    monthly=pd.read_sql_query("""SELECT region,substr(order_date,1,7) month,ROUND(SUM(sales_inr),2) sales,ROUND(SUM(profit_inr),2) profit,COUNT(order_id) orders FROM orders_clean GROUP BY region,month ORDER BY region,month""",con)
    monthly.to_csv(OUT/"monthly_metrics.csv",index=False)
    p=monthly.pivot(index="region",columns="month",values="sales").fillna(0); rows=[]
    for r in p.index:
        a=float(p.loc[r].get("2026-04",0));m=float(p.loc[r].get("2026-05",0));j=float(p.loc[r].get("2026-06",0))
        rows.append([r,a,m,j,pct_change(m,a),pct_change(j,m),abs(pct_change(m,a))>8,abs(pct_change(j,m))>8])
    growth=pd.DataFrame(rows,columns=["region","apr_sales","may_sales","jun_sales","apr_may_pct","may_jun_pct","apr_may_flag","may_jun_flag"])
    growth.to_csv(OUT/"regional_growth.csv",index=False)
    assert checks["orders_count"]==2100 and checks["duplicate_key_count"]==0 and checks["kurnool_order_count"]==0
    assert checks["left_join_count"]==2101 and checks["inner_join_count"]==2100
    assert float(growth.loc[growth.region=="Guntur","apr_may_pct"].iloc[0])==122.19
    april=monthly[monthly.month=="2026-04"].to_dict("records"); save_state("april_summary.json",april)
    flagged=growth[(growth.apr_may_flag)|(growth.may_jun_flag)]
    narrative=[]
    for _,r in flagged.iterrows():
        narrative.append({"region":r.region,"context":f"In April 2026, {r.region} recorded sales of INR {r.apr_sales:,.2f}.",
        "insight":f"Sales changed to INR {r.may_sales:,.2f} in May ({r.apr_may_pct:+.2f}% MoM) and INR {r.jun_sales:,.2f} in June ({r.may_jun_pct:+.2f}% MoM).",
        "implication":"The movement crosses the 8% monitoring threshold; review operational, promotional and data-quality context before assigning a cause."})
    (OUT/"cii_narratives.json").write_text(json.dumps(narrative,indent=2))
    audit={"timestamp_utc":datetime.now(timezone.utc).isoformat(),"run_id":datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ"),"region":"Guntur","decision":"edit","note":"Draft requires human review before sign-off."}
    with open(OUT/"audit_log.jsonl","a") as f:f.write(json.dumps(audit)+"\n")
    g=growth[growth.region=="Guntur"].iloc[0]
    (OUT/"memo.md").write_text(f"""# PharmEasy Regional Pulse — One-Page Decision Memo
## Context
The Q2 2026 export contains 2,159 raw rows. After removing 59 exact duplicates and correcting known data-quality issues, the analytical dataset contains 2,100 unique orders across 9 active regions. Kurnool is retained in the 10-row master but has zero orders.
## Key Insight
Guntur sales increased from INR {g.apr_sales:,.2f} in April to INR {g.may_sales:,.2f} in May, a **+{g.apr_may_pct:.2f}% MoM change**. The 8% threshold is a monitoring heuristic, not a statistical significance test.
## Evidence
- Raw rows: 2,159
- Exact duplicates removed: 59
- Clean orders: 2,100
- Missing categories filled: 48
- Missing profits filled: 94
- Master regions: 10
- Active regions with orders: 9
- Kurnool orders: 0
- Guntur Apr→May change: +{g.apr_may_pct:.2f}%
## Recommendation
Treat the Guntur movement as an investigation trigger. Review promotions, product mix, operational events and source-system anomalies before attributing a cause.
## Next Check
Re-run the pipeline on the next monthly export and compare flagged regions with the saved prior state.
## Assumptions
Missing categories are inferred from product mappings. Missing profit is estimated using observed category-level mean profit margin. The 8% rule is a monitoring heuristic.
""")
    (OUT/"reliability_checklist.md").write_text("""# Reliability Checklist
- [x] No PII is included in the generated dataset.
- [x] Schema, duplicate-key, row-count and master-region checks pass.
- [x] Guntur growth is cross-checked from SQL output.
- [x] Generator is deterministic with seed 2026.
- [ ] Human sign-off: reviewer must inspect final memo/dashboard before submission.
""")
    (OUT/"presentation_storyline.md").write_text(f"""# Stakeholder Presentation Storyline
## Executive — Situation / Complication / Resolution
**Situation:** Q2 2026 regional sales are available after a reproducible cleaning and validation pipeline.
**Complication:** Guntur moved from INR {g.apr_sales:,.2f} in April to INR {g.may_sales:,.2f} in May, a +{g.apr_may_pct:.2f}% MoM change above the 8% monitoring threshold.
**Resolution:** Use the dashboard and SQL evidence to investigate the drivers, validate source integrity and monitor the next month before assigning a business cause.
## Regional Manager — Overview / Category / Detail
1. Overview: KPI totals and regional sales trend.
2. Category: category contribution for the selected region.
3. Detail: region-month sales/profit and SQL-verified flags.
""")
    con.close(); print("Pipeline completed.")
if __name__=="__main__":main()
