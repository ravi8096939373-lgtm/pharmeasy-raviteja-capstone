-- SQLite verification queries
SELECT COUNT(*) AS clean_rows FROM orders_clean;
SELECT order_id,COUNT(*) AS n FROM orders_clean GROUP BY order_id HAVING COUNT(*)>1;
SELECT r.region,COUNT(o.order_id) order_count,COALESCE(SUM(o.sales_inr),0) sales_inr,COALESCE(SUM(o.profit_inr),0) profit_inr
FROM regions_master r LEFT JOIN orders_clean o ON r.region=o.region GROUP BY r.region ORDER BY r.region;
SELECT COUNT(*) AS left_join_rows FROM regions_master r LEFT JOIN orders_clean o ON r.region=o.region;
SELECT COUNT(*) AS inner_join_rows FROM regions_master r INNER JOIN orders_clean o ON r.region=o.region;
SELECT region,substr(order_date,1,7) month,ROUND(SUM(sales_inr),2) sales_inr FROM orders_clean GROUP BY region,month ORDER BY region,month;
WITH monthly AS (SELECT region,substr(order_date,1,7) month,SUM(sales_inr) sales FROM orders_clean WHERE region='Guntur' GROUP BY region,month)
SELECT ROUND(MAX(CASE WHEN month='2026-04' THEN sales END),2) april_sales,
ROUND(MAX(CASE WHEN month='2026-05' THEN sales END),2) may_sales,
ROUND((MAX(CASE WHEN month='2026-05' THEN sales END)/MAX(CASE WHEN month='2026-04' THEN sales END)-1)*100,2) apr_may_pct
FROM monthly;
