# Reliability Checklist
- [x] No PII is included in the generated dataset.
- [x] Schema, duplicate-key, row-count and master-region checks pass.
- [x] Guntur growth is cross-checked from SQL output.
- [x] Generator is deterministic with seed 2026.
- [ ] Human sign-off: reviewer must inspect final memo/dashboard before submission.
