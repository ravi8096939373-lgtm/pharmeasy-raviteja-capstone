# PharmEasy Regional Pulse — One-Page Decision Memo
## Context
The Q2 2026 export contains 2,159 raw rows. After removing 59 exact duplicates and correcting known data-quality issues, the analytical dataset contains 2,100 unique orders across 9 active regions. Kurnool is retained in the 10-row master but has zero orders.
## Key Insight
Guntur sales increased from INR 100,000.00 in April to INR 222,190.00 in May, a **+122.19% MoM change**. The 8% threshold is a monitoring heuristic, not a statistical significance test.
## Evidence
- Raw rows: 2,159
- Exact duplicates removed: 59
- Clean orders: 2,100
- Missing categories filled: 48
- Missing profits filled: 94
- Master regions: 10
- Active regions with orders: 9
- Kurnool orders: 0
- Guntur Apr→May change: +122.19%
## Recommendation
Treat the Guntur movement as an investigation trigger. Review promotions, product mix, operational events and source-system anomalies before attributing a cause.
## Next Check
Re-run the pipeline on the next monthly export and compare flagged regions with the saved prior state.
## Assumptions
Missing categories are inferred from product mappings. Missing profit is estimated using observed category-level mean profit margin. The 8% rule is a monitoring heuristic.
