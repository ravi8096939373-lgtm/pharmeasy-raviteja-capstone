# Stakeholder Presentation Storyline
## Executive — Situation / Complication / Resolution
**Situation:** Q2 2026 regional sales are available after a reproducible cleaning and validation pipeline.
**Complication:** Guntur moved from INR 100,000.00 in April to INR 222,190.00 in May, a +122.19% MoM change above the 8% monitoring threshold.
**Resolution:** Use the dashboard and SQL evidence to investigate the drivers, validate source integrity and monitor the next month before assigning a business cause.
## Regional Manager — Overview / Category / Detail
1. Overview: KPI totals and regional sales trend.
2. Category: category contribution for the selected region.
3. Detail: region-month sales/profit and SQL-verified flags.
